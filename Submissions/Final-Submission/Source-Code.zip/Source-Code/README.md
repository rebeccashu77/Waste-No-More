# WasteNoMore Virtual Fridge

The structure of the code follows a normal tree structure with class components containing several functional components. The class components (containers) can pass their state or pieces of their state as properties to the functional components. These functional components can take in these properties and can alter them or dispatch certain actions. Dispatched actions are received by the action creators (the folder titled ‘actions’) which halt these dispatches giving the dbms time to respond - this is the asynchronous call made to the dbms. Once information is received from the dbms, the dispatch proceeds to the reducers (folder is titled ‘reducers’) which are connected to the root reducer. The root reducer manages the state of the react components and updates them according to the changes in the root reducer. Compiling this code requires installing several modules (shown below) along with having node.js installed. Set up is relatively easy as firebase provides clear instructions on how to deploy a website hosted on their server (here: https://firebase.google.com/docs/hosting?authuser=0). Deployment requires having a firebase account (google account works). Updating any indexes or rules for user access in the backend is accomplished via the firestore project directly. Limitations of this structure include the halting process and the frustrating lack of methods for arrays in firestore. David and Griffin had communicated about using arrays for storing some of our data and firestore lacks efficient ways to navigate these arrays using react components.

Modules/packages required for deployment: 
apt install node (or brew install node)
npm install bootstrap
npm install react-bootstrap bootstrap
npm install react-router-dom
npm install redux-thunk
npm install react-redux
npm install react-redux-firebase
npm install redux
npm install redux-firestore
npm install moment
npm install react-datepicker

Setup and Deployment:
npx create-react-app my-app:creates react app that is ready to be built (move src folder with code into the resulting directory)
npm start: runs app locally
npm run build: should generate a build directory for deployment
npm install -g firebase-tools: firebase-tools
npm init <directory>: prepares the directory for deployment (should be build in this case)
firebase login: must have a firebase account (linked to google account)
deploy firebase             
