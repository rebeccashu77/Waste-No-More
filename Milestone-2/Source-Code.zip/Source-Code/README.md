# cs316_project

To create and load the WasteNoMore database, navigate to the directory containing the create.sql and load.sql files and run the following commands: <br />
1. dropdb wastenomore
2. createdb wastenomore
3. psql wastenomore -af create.sql
4. psql wastenomore -af load.sql

For the production dataset, the biggest need for the team was to obtain a large list of different foods and their expiration dates. This was done manually by finding expiration dates for a variety of foods on eatbydate.com. In addition, the team created a massive amount of sample user data to make the results for queries larger.

To use the Edamam API to query recipes, the following is needed:
-Application ID: 6d7ce185
-Application Key: 5804143089244e89c9341a6404ddf092

The Edamam Recipe Search API allows users to search by ingredients, dietary restrictions, and much more. Queries from the Edamam API are returned in a JSON format. For the final submission, in order to suggest recipes to the user, the team will have to write code to parse the JSON files returned by calls to the API. More information on how to use the Edamam Recipe Search API can be found at the following link:
https://developer.edamam.com/edamam-docs-recipe-api

A sample recipe query is as follows (this query gets recipes for chicken that are alcohol-free and have from 591-722 calories):
https://api.edamam.com/search?q=chicken&app_id=$6d7ce185&app_key=$5804143089244e89c9341a6404ddf092&from=0&to=3&calories=591-722&health=alcohol-free

